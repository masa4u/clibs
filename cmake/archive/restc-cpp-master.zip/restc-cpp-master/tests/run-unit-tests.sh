#!/bin/sh
./tests/run-tests.sh build/tests/unit
