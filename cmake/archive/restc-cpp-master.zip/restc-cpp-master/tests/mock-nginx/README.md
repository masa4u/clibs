
Docker container scripts for a nginx instance used by the tests
in the project.

Start the jsonserver docker instance (see ../mock-server), and then:
```sh
$ ./build_and_run.sh
```
