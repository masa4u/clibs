#include "restc-cpp/restc-cpp.h"
#include "restc-cpp/IteratorFromJsonSerializer.h"
#include "restc-cpp/RequestBuilder.h"

namespace {
	void foo() {}
}