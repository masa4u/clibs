@mainpage

# Taking the pain out of REST in C++

 - @ref README.md
 - @ref doc/GettingStarted.md
 - @ref doc/Tutorial.md
 - @ref doc/RunningTheTests.md

Home page: https://github.com/jgaa/restc-cpp

