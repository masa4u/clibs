# levmar
Levenberg-Marquardt nonlinear least squares algorithms in C/C++.

This is a Psi4 wrapping of the levmar library from http://users.ics.forth.gr/~lourakis/levmar/.

## License
The original levmar code is licensed under GPL 2.0 located in src/LICENSE.
